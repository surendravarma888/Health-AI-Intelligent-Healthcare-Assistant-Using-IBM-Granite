
# HealthAI: Intelligent Healthcare Assistant (Mock Version)

This is a demo version of the HealthAI app using Streamlit and mocked IBM Granite AI responses.

## Modules
- Patient Chat
- Disease Prediction
- Treatment Plans
- Health Analytics

## How to Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

Replace mocked responses with real IBM Watson Granite integration as needed.
