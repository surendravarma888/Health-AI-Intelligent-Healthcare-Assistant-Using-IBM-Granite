
def patient_chat_response(query):
    # Mocked response
    return f"This is a general answer to your question: '{query}'. Please consult a healthcare provider for accurate diagnosis."
