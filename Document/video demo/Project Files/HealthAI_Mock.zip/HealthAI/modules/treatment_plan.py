
def generate_treatment_plan(condition):
    # Mocked logic
    return f"For {condition}, recommended treatment may include medication, lifestyle changes, and regular monitoring. Please follow up with your doctor."
